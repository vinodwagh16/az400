﻿namespace Microsoft.eShopWeb.Web.ViewModels.Manage
{
    public class GenerateRecoveryCodesViewModel
    {
        public string[] RecoveryCodes { get; set; }
    }
}
